#ifndef servo_h
#define servo_h

void InitServo();
void setServo(unsigned int pressedKey);
void goServo();

#endif