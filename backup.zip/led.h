#ifndef led_h
#define led_h
void setLed(unsigned int onoff);
void configLed(void);


#endif