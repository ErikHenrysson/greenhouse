#ifndef printTemp_h
#define printTemp_h
#include "structs.h"
//void printMinMaxAvg(struct LinkedList* first);
void printTemp(int temperature);
#endif